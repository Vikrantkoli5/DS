

public class MPISum {

    public static void main(String[] args) {

    }
}
